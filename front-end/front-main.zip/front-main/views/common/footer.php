<!-- Pied de page -->
<footer class="bg-[#15171A] text-center py-4">
    <p class="text-white">
        © 2023 Médiathèque. Tous droits réservés.
        -
        <a href="/api" class="text-white hover:underline">Accès développeur</a>
    </p>
</footer>
</body>

</html>